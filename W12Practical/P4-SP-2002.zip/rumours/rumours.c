/**
 * @file rumours.c
 * @author your student ID
 * @brief 
 * 
 */


int main(int argc, int *argv[])
{

   return 0;
}