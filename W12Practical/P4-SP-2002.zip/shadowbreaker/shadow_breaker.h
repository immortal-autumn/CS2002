/**
 * Header to link and launch YOUR start function from _main.c
 */

#include <stddef.h>

// Function called from shadow_breaker main()
int start(size_t thread_count);
